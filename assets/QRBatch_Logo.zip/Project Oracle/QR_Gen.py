#!/usr/bin/env python
#
#Code used to encode, modify, and test an arbitrary
#set of QR codes.
#
#qrencode must be installed.
#INSTALL: sudo apt-get install qrencode
#
#Inputs: csv file for where the data should be placed
#   Col A - String to encode
#   Col B - Path for embedded image. Leave blank if none.
#Outputs:
#   A folder with all QR codes of the csv file.
#   A folder with all modified QR codes.
#
#Written by Leo Szeto, www.leoszeto.com

#TODO: Pull up dialog for path names that each folder will be placed.

import csv
import os
import PIL
import Image

job_size = 0
cur_job  = 1

ORIG_QRCODE = 'ORIG_QRCODE'
MODI_QRCODE = 'MODI_QRCODE'
IMG_FOLDER  = 'IMG'

#Size of the mod in (1/n) relation to the original image. use smaller numbers to get larger images.
MOD_SIZE = 5

#Create folders
os.system('mkdir -p ' + ORIG_QRCODE)
os.system('mkdir -p ' + MODI_QRCODE)

#Determine size of job
#Open the file using csv.reader
qrReader = csv.reader(open('qrinput.csv', 'rb'), delimiter = ',' , quotechar = '|')
for row in qrReader:
	#Ignore comments (#)
	if row[0][0] != '#':
		job_size = job_size + 1
print "Job Size: " + str(job_size)

#Start the conversion process
qrReader = csv.reader(open('qrinput.csv', 'rb'), delimiter = ',', quotechar = '|')
if job_size > 0:
	for row in qrReader:
		#Print some data about the job		
		print "Current Job: " + str(cur_job) + '/' + str(job_size) + " | QR Data: " + row[0] + " | QR Image: " + row[1] + " | QR Desc: " + row[2]
		cur_job = cur_job + 1
		#Generate and execute the command for the original QR image
		command = 'qrencode -v 6 -o ' + ORIG_QRCODE + '/' + row[2] + '.png -s 6 \'' + row[0] + '\''
		os.system(command)
		#Now, start work on creating a Logo-ized QR code.
		#If there is none, then just skip this step and copy the original QR image directly to modified.		
		if row[1] != '':		
			print "Performing logo pasting"
			ORIG_PATH = ORIG_QRCODE + '/' + row[2] + '.png'
			MODI_PATH = MODI_QRCODE + '/' + row[2] + '_logo.png'
			IMG_PATH = IMG_FOLDER + '/' + row[1]
			im = Image.open(ORIG_PATH)
			mod = Image.open(IMG_PATH)
			#Determine some important parameters		
			modx = im.size[0]/MOD_SIZE
			mody = im.size[1]/MOD_SIZE
			posx = (im.size[0] - modx)/2
			posy = (im.size[1] - mody)/2
			#Spit out a warning if the image size is large or if the ratio between modx and mody is large
			if im.size[0]*im.size[1] > 256*256:
				print "WARNING: logo size too large, artifacting might occur."
			if modx != mody:
				print "WARNING: logo is not square, undesirable results might occur."
			#Resize the logo to ensure that it is the right size
			mod_sized = mod.resize((modx,mody))
			#Paste the resulting code
			im.paste(mod_sized, (posx, posy))
			#Save the image here
			im.save(MODI_PATH, "PNG")
		else:
			print "No Logo: Pasting original into modified folder"
			#Save the image here
			ommand = 'qrencode -v 6 -o ' + MODI_QRCODE + '/' + row[2] + '_nologo.png -s 6 \'' + row[0] + '\''
			os.system(command)		

	print "Done!"
else:
	print "Error: No CSV data found!"

